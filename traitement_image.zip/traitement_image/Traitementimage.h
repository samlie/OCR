#ifndef TRAITEMENTIMAGE_H
#define TRAITEMENTIMAGE_H


void readimage();
void header();


#endif