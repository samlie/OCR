#ifndef DECOUPAGE_H
#define DECOUPAGE_H

#include <stdlib.h>
#include <SDL.h>

void printMat(size_t nbrows, size_t nbcols, int mat[nbrows][nbcols]);
void initialize(size_t nbrows, size_t nbcols, int mat[nbrows][nbcols]);
void boundAndColor(size_t nbrows, size_t nbcols, int mat[nbrows][nbcols], size_t rows, size_t cols, int nb, size_t bounds[4]);
void matrixdec(size_t nbrows,size_t nbcols, int mat[nbrows][nbcols], size_t bounds[4], int mat2[nbrows][nbcols], int key);
void isoleTache(size_t nbmats, size_t nbrows, size_t nbcols, int mat[nbrows][nbcols]);

#endif